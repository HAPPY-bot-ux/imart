
// main.js
document.addEventListener('DOMContentLoaded', ()=>{

  // Simple scroll reveal (cross reveal style)
  const els = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting) {
        e.target.classList.add('revealed');
      }
    });
  }, {threshold:0.12});
  els.forEach(el=>io.observe(el));

  // WhatsApp link generator for product buttons and contact form
  const WA_NUMBER = "27611234567"; // <-- replace with your full phone number (country code + number), example: 2761...
  // product buttons
  document.querySelectorAll('[data-wa-msg]').forEach(btn=>{
    btn.addEventListener('click', (ev)=>{
      ev.preventDefault();
      const msg = encodeURIComponent(btn.getAttribute('data-wa-msg'));
      const url = `https://wa.me/${WA_NUMBER}?text=${msg}`;
      window.open(url, '_blank');
    });
  });

  // contact form: open whatsapp with message
  const form = document.getElementById('contactForm');
  if(form){
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const name = form.querySelector('[name=name]').value || 'Customer';
      const email = form.querySelector('[name=email]').value || '';
      const phone = form.querySelector('[name=phone]').value || '';
      const message = form.querySelector('[name=message]').value || '';
      const msg = encodeURIComponent(`Hello! My name is ${name}. I'm contacting regarding: ${message} -- Email: ${email} -- Phone: ${phone}`);
      const url = `https://wa.me/${WA_NUMBER}?text=${msg}`;
      window.open(url, '_blank');
    });
  }

});
